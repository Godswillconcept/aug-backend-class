const os = require("os");

// console.log(os);
// console.log(os.userInfo()); // return the user information
// console.log(os.totalmem()); // total memory in bytes
// console.log(os.freemem()); // ree memory in bytes
// console.log("used mem:", os.totalmem() - os.freemem());
// console.log(os.platform());
// console.log(os.hostname());
// console.log("uptime", os.uptime() / 3600); // system uptime in number of seconds
// console.log(os.release()); // return the operating system
// console.log(os.tmpdir());
console.log(os.type()); // return the type of os