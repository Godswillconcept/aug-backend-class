const person = { fname: "John", lname: "Doe" };
const user = { fname: "John", lname: "Doe" };
// console.log(user);

module.exports = { user, person };
// const lodash = require("lodash");

// const users = ["Matthew", "Enoch", "Faruq", "Bolu", "Malik"];
// const output = lodash.chunk(users, 2);
// console.log(output);
// const values = [1, 2, 3, "", 0, false, true, 5];
// const res = lodash.compact(values);
// console.log(res);

// const arr = [1, [2, [3, [4, 5], [6, 7], 8], 9], 10];
// const result = lodash.flattenDeep(arr);
// console.log(result);

// const str = "The boss is here";
// console.log(lodash.camelCase(str));
// console.log(lodash.capitalize(str));
// console.log(lodash.endsWith(str, "boss"));
// console.log(lodash.startsWith(str, "boss"));
// console.log(
//   lodash.truncate(str, {
//     length: 15,
//   })
// );


